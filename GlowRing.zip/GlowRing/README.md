# GlowRing

Control the **Back light effects** ring (the LEDs around the camera lenses) of the Redmi Turbo 4 Pro
from your own app: any RGB color, breathing, rainbow, police, music reaction, notification / call /
charger / game lighting, and Quick Settings tiles.

## 1. Build the APK on GitHub (no Android Studio)

1. Create a new repository on GitHub.
2. Upload everything in this folder, including the hidden `.github` folder, to the `main` branch.
3. Open the **Actions** tab. *Build APK* runs automatically (about 5 minutes).
4. Download `GlowRing.apk` from **Releases** (right side of the repo page) and install it.

If the build fails, open the failed step and send the red error text.

## 2. One-time phone setup (needed, no root)

HyperOS only lets system apps drive the ring, so GlowRing talks to it through **Shizuku**:

1. Install **Shizuku** (Google Play or its GitHub page).
2. Open Shizuku and start it with **Wireless debugging** (the app shows the steps). Repeat after each reboot.
3. Open GlowRing, tap **Allow** in the setup card.
4. In Android **Settings > Back light effects**, switch it **On** (it must be on or the ring stays dark).
5. Tap **Test the ring**.

Then add the **Back Glow** and **Glow Effect** tiles: pull down Quick Settings, tap edit, drag them in.
Also set GlowRing to **No restrictions** in Settings > Apps > GlowRing > Battery saver and allow Autostart.

## Notes

- Not tested on a real phone by the author. The ring protocol (`miui.lights.ILightsManager` through Shizuku)
  comes from the open-source Aura project (MIT License, https://github.com/tgvdufuture/Aura), which reports
  it working on POCO X8 Pro / HyperOS 3. The Redmi Turbo 4 Pro should use the same service but this is unconfirmed.
- If the HyperOS built-in ring features (notifications, rhythm, charging) are also on, both may light at once.
  Turn the built-in ones off under Back light effects.
- The system clears a claimed light after 30 minutes, so long effects re-claim every 25 minutes (a brief blink).
- Police, Strobe and Disco ask for a photosensitivity confirmation.
- The 3D phone is a drawn model, drag to rotate; it is not a scan of the exact device.
