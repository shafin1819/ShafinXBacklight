package com.flashglow.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import com.flashglow.app.MainActivity
import com.flashglow.app.R
import com.flashglow.app.core.Effect
import com.flashglow.app.core.RingEngine
import com.flashglow.app.core.Perms
import com.flashglow.app.core.Prefs
import com.flashglow.app.core.Request
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Keeps the process alive while any light feature is active and hosts the
 * charger and game-mode watchers. It stops itself once nothing needs it.
 */
class FlashService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var gameJob: Job? = null
    private var chargeRx: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.service_channel), NotificationManager.IMPORTANCE_MIN),
        )
        goForeground() // must happen before anything can call stopSelf()
        RingEngine.manualOn.onEach { sync() }.launchIn(scope)
        Prefs.state.onEach { sync() }.launchIn(scope)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        if (intent?.action == ACTION_STOP) RingEngine.stopManual()
        sync()
        return START_STICKY
    }

    private fun goForeground() {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FlashService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_tile_glow)
            .setContentTitle("GlowRing is active")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Turn off", stop).build())
            .build()
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        if (Perms.hasMic(this) && Prefs.state.value.effect == Effect.MUSIC) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        }
        try {
            startForeground(1, n, type)
        } catch (e: Exception) {
            // Mic type can be refused when started from the background; retry without it.
            try {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } catch (_: Exception) {
                stopSelf()
            }
        }
    }

    @Synchronized
    private fun sync() {
        val s = Prefs.state.value
        val manual = RingEngine.manualOn.value

        // Charger animation
        if (s.chargeGlow && chargeRx == null) {
            chargeRx = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    val st = Prefs.state.value
                    if (st.chargeGlow) {
                        RingEngine.alert("charge", Effect.BREATHE, st.chargeColor, st.brightness, 0.6f, 3200)
                    }
                }
            }
            registerReceiver(chargeRx, IntentFilter(Intent.ACTION_POWER_CONNECTED), RECEIVER_NOT_EXPORTED)
        } else if (!s.chargeGlow && chargeRx != null) {
            unregisterReceiver(chargeRx)
            chargeRx = null
        }

        // Game mode
        if (s.gameMode && gameJob == null) {
            gameJob = scope.launch { watchGames() }
        } else if (!s.gameMode && gameJob != null) {
            gameJob?.cancel()
            gameJob = null
            RingEngine.setGame(null)
        }

        if (!manual && !s.chargeGlow && !s.gameMode) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private suspend fun watchGames() {
        val usm = getSystemService(UsageStatsManager::class.java)
        val pm = getSystemService(PowerManager::class.java)
        var lastPkg: String? = null
        var lastQuery = System.currentTimeMillis() - 60_000
        while (scope.isActive) {
            val s = Prefs.state.value
            if (!pm.isInteractive || !Perms.hasUsageAccess(this)) {
                RingEngine.setGame(null)
                lastPkg = null
                delay(3000)
                continue
            }
            val now = System.currentTimeMillis()
            val ev = usm.queryEvents(lastQuery, now)
            val e = UsageEvents.Event()
            var fg: String? = lastPkg
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) fg = e.packageName
            }
            lastQuery = now - 1000
            lastPkg = fg
            val isGame = fg != null && fg != packageName && isGame(fg, s.extraGames)
            RingEngine.setGame(
                if (isGame) Request(s.gameEffect, s.gameColor, s.brightness, s.speed, "game") else null,
            )
            delay(2000)
        }
    }

    private fun isGame(pkg: String, extra: Set<String>): Boolean {
        if (pkg in extra) return true
        return try {
            val info = packageManager.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
            info.category == ApplicationInfo.CATEGORY_GAME
        } catch (_: Exception) {
            false
        }
    }

    override fun onDestroy() {
        gameJob?.cancel()
        chargeRx?.let { try { unregisterReceiver(it) } catch (_: Exception) { } }
        chargeRx = null
        RingEngine.setGame(null)
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "flashglow_service"
        const val ACTION_STOP = "com.flashglow.app.STOP"

        fun start(c: Context) {
            try {
                c.startForegroundService(Intent(c, FlashService::class.java))
            } catch (_: Exception) { }
        }

        /** Starts the service when a feature needs it; the service stops itself otherwise. */
        fun refresh(c: Context) {
            val s = Prefs.state.value
            if (RingEngine.manualOn.value || s.chargeGlow || s.gameMode) start(c)
        }
    }
}
