package com.flashglow.app.core

enum class Effect(val label: String, val hint: String) {
    STEADY("Steady", "Constant color"),
    BREATHE("Breathe", "Slow fade in and out"),
    PULSE("Pulse", "Even on and off blink"),
    HEARTBEAT("Heartbeat", "Lub-dub rhythm"),
    RAINBOW("Rainbow", "Cycles through every color"),
    POLICE("Police", "Red and blue alternate"),
    STROBE("Strobe", "Fast flashing"),
    DISCO("Disco", "Random colors flicker"),
    MUSIC("Music", "Reacts to sound via the microphone");

    /** Effects that flash quickly enough to warrant a photosensitivity warning. */
    val isFlashy: Boolean get() = this == STROBE || this == DISCO || this == POLICE

    companion object {
        fun of(name: String?, fallback: Effect): Effect =
            entries.firstOrNull { it.name == name } ?: fallback
    }
}

/** What the ring should currently be doing. */
data class Request(
    val effect: Effect,
    val color: Int, // 0xRRGGBB
    val brightness: Float, // 0.1..1
    val speed: Float, // 0..1
    val key: String = "",
)

object Colors {
    val swatches = listOf(
        0xFFFFFF, 0xFF3B30, 0xFF9500, 0xFFD60A, 0x34C759,
        0x00C7BE, 0x0A84FF, 0x5E5CE6, 0xBF5AF2, 0xFF2D92,
    )

    fun scale(color: Int, k: Float): Int {
        val f = k.coerceIn(0f, 1f)
        val r = (((color shr 16) and 0xFF) * f).toInt()
        val g = (((color shr 8) and 0xFF) * f).toInt()
        val b = ((color and 0xFF) * f).toInt()
        return (r shl 16) or (g shl 8) or b
    }

    fun hsv(h: Float, s: Float = 1f, v: Float = 1f): Int =
        android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)) and 0xFFFFFF

    fun hue(color: Int): Float {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(color or (0xFF shl 24), hsv)
        return hsv[0]
    }

    fun isGrey(color: Int): Boolean {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(color or (0xFF shl 24), hsv)
        return hsv[1] < 0.15f
    }
}
