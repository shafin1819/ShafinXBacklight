package com.flashglow.app.ui

import android.Manifest
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.flashglow.app.core.Effect
import com.flashglow.app.core.Glow
import com.flashglow.app.core.Link
import com.flashglow.app.core.Perms
import com.flashglow.app.core.Prefs
import com.flashglow.app.core.RingEngine
import com.flashglow.app.core.ShizukuState

@Composable
fun HomeScreen() {
    val ctx: Context = LocalContext.current
    val s by Prefs.state.collectAsStateWithLifecycle()
    val on by RingEngine.manualOn.collectAsStateWithLifecycle()
    val shown by RingEngine.color.collectAsStateWithLifecycle()
    val link by ShizukuState.link.collectAsStateWithLifecycle()
    val error by RingEngine.error.collectAsStateWithLifecycle()

    var warnFor by remember { mutableStateOf<Effect?>(null) }
    var pendingMusic by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok && pendingMusic) {
            Prefs.update { it.copy(effect = Effect.MUSIC) }
            Glow.apply(ctx)
        }
        pendingMusic = false
    }

    fun pick(e: Effect) {
        when {
            e.isFlashy && !s.flashyAck -> warnFor = e
            e == Effect.MUSIC && !Perms.hasMic(ctx) -> {
                pendingMusic = true
                micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
            else -> {
                Prefs.update { it.copy(effect = e) }
                Glow.apply(ctx)
            }
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PhoneView(ring = if (on || shown != 0) shown else 0)

        SetupCard(link)

        Text(
            when {
                error != null -> error!!
                on -> "${s.effect.label} - ${s.effect.hint}"
                else -> "Tap the button to light up the back ring"
            },
            color = if (error != null) Pal.danger else Pal.dim,
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
            PowerButton(on = on, enabled = link == Link.READY) { Glow.toggle(ctx) }
        }
        if (link == Link.READY && !on) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                SmallButton("Test the ring") { RingEngine.test() }
            }
        }

        SectionLabel("Effect")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(Effect.entries.toList()) { e ->
                Chip(e.label, s.effect == e) { pick(e) }
            }
        }

        SectionLabel("Color")
        Card {
            ColorPicker(s.color) { c ->
                Prefs.update { it.copy(color = c) }
                Glow.apply(ctx)
            }
            if (s.effect == Effect.RAINBOW || s.effect == Effect.POLICE || s.effect == Effect.DISCO) {
                Spacer(Modifier.height(4.dp))
                Text("${s.effect.label} uses its own colors.", color = Pal.dim, fontSize = 11.sp)
            }
        }

        Card {
            LabeledSlider(
                label = "Brightness",
                value = s.brightness,
                onChange = { v -> Prefs.update { it.copy(brightness = v.coerceAtLeast(0.1f)) }; Glow.apply(ctx) },
                onDone = {},
            )
            Spacer(Modifier.height(6.dp))
            LabeledSlider(
                label = "Speed",
                value = s.speed,
                onChange = { v -> Prefs.update { it.copy(speed = v) }; Glow.apply(ctx) },
                onDone = {},
            )
        }

        SectionLabel("Auto turn off")
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf(0, 5, 15, 30, 60)) { m ->
                Chip(if (m == 0) "Never" else "$m min", s.autoOffMin == m) {
                    Prefs.update { it.copy(autoOffMin = m) }
                }
            }
        }
        Text(
            "Applies the next time you turn the light on.",
            color = Pal.dim, fontSize = 11.sp,
        )
    }

    warnFor?.let { e ->
        AlertDialog(
            onDismissRequest = { warnFor = null },
            containerColor = Pal.card,
            title = { Text("Flashing light warning", color = Pal.text) },
            text = {
                Text(
                    "${e.label} flashes quickly and may trigger seizures in people with photosensitive epilepsy. Use it only if that is safe for you and anyone nearby.",
                    color = Pal.dim,
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.update { it.copy(flashyAck = true, effect = e) }
                    Glow.apply(ctx)
                    warnFor = null
                }) { Text("I understand", color = Pal.accent) }
            },
            dismissButton = {
                TextButton(onClick = { warnFor = null }) { Text("Cancel", color = Pal.dim) }
            },
        )
    }
}

/** Walks the user through the one-time Shizuku setup; hidden once it is ready. */
@Composable
private fun SetupCard(link: Link) {
    val ctx = LocalContext.current
    if (link == Link.READY) return
    Card {
        Text("One-time setup", color = Pal.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text(
            "HyperOS only lets system apps control the back ring. Shizuku (a free app) gives GlowRing that permission without root.",
            color = Pal.dim, fontSize = 12.sp,
        )
        Spacer(Modifier.height(10.dp))
        val steps = if (link == Link.NOT_RUNNING) {
            listOf(
                "1. Install Shizuku from Google Play or its GitHub page.",
                "2. Open Shizuku and start it with Wireless debugging (it shows the steps).",
                "3. Come back here.",
            )
        } else {
            listOf("Shizuku is running. Allow GlowRing to use it.")
        }
        steps.forEach { Text(it, color = Pal.text, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp)) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (link == Link.NOT_RUNNING) {
                SmallButton("Open Shizuku") { ShizukuState.openShizukuApp(ctx) }
                SmallButton("Check again") { ShizukuState.refresh() }
            } else {
                SmallButton("Allow") { ShizukuState.requestPermission() }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Also turn on Settings > Back light effects, or the ring stays dark.",
            color = Pal.dim, fontSize = 11.sp,
        )
    }
}

@Composable
private fun PowerButton(on: Boolean, enabled: Boolean, onClick: () -> Unit) {
    val fill by animateColorAsState(if (on) Pal.accent else Color(0xFF1B1C22), label = "fill")
    val label by animateColorAsState(
        if (!enabled) Pal.dim else if (on) Color(0xFF1A1100) else Pal.text, label = "label",
    )
    Row(
        Modifier
            .clip(CircleShape)
            .background(fill)
            .border(1.dp, if (on) Pal.accent else Pal.line, CircleShape)
            .clickable(enabled = enabled, onClick = onClick)
            .size(width = 200.dp, height = 62.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            if (on) "Turn off" else "Turn on",
            color = label,
            fontSize = 17.sp,
            fontWeight = FontWeight.SemiBold,
        )
    }
}
