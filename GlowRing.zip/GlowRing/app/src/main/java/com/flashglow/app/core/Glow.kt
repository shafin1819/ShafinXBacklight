package com.flashglow.app.core

import android.content.Context
import com.flashglow.app.service.FlashService

/** Entry points shared by the app screen, the Quick Settings tiles and the services. */
object Glow {
    fun isOn(): Boolean = RingEngine.manualOn.value

    fun toggle(c: Context) {
        if (isOn()) turnOff(c) else turnOn(c)
    }

    fun turnOn(c: Context) {
        ShizukuState.refresh()
        val s = Prefs.state.value
        // Never auto-start a flashing effect the user has not agreed to.
        val effect = if (s.effect.isFlashy && !s.flashyAck) Effect.BREATHE else s.effect
        RingEngine.startManual(effect, s.color, s.brightness, s.speed, s.autoOffMin)
        FlashService.start(c)
    }

    fun turnOff(c: Context) {
        RingEngine.stopManual()
        FlashService.refresh(c)
    }

    /** Pushes the current settings to a running manual effect. */
    fun apply(c: Context) {
        val s = Prefs.state.value
        RingEngine.updateManual(s.effect, s.color, s.brightness, s.speed)
        FlashService.refresh(c)
    }

    /** Effects a tile may cycle through without prompting. */
    fun cycleList(c: Context, s: Settings): List<Effect> =
        Effect.entries.filter {
            !(it.isFlashy && !s.flashyAck) && (it != Effect.MUSIC || Perms.hasMic(c))
        }
}
