package com.flashglow.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flashglow.app.ui.AutoScreen
import com.flashglow.app.ui.Chip
import com.flashglow.app.ui.FlashTheme
import com.flashglow.app.ui.HomeScreen
import com.flashglow.app.ui.Pal

class MainActivity : ComponentActivity() {
    override fun onResume() {
        super.onResume()
        com.flashglow.app.core.ShizukuState.refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FlashTheme {
                var tab by rememberSaveable { mutableIntStateOf(0) }
                Box(Modifier.fillMaxSize().background(Pal.bg)) {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .statusBarsPadding()
                            .navigationBarsPadding()
                            .verticalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                    ) {
                        Spacer(Modifier.height(14.dp))
                        Text("GlowRing", color = Pal.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("Back light ring studio", color = Pal.dim, fontSize = 13.sp)
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Chip("Light", tab == 0) { tab = 0 }
                            Chip("Automations", tab == 1) { tab = 1 }
                        }
                        Spacer(Modifier.height(14.dp))
                        if (tab == 0) HomeScreen() else AutoScreen()
                        Spacer(Modifier.height(28.dp))
                    }
                }
            }
        }
    }
}
