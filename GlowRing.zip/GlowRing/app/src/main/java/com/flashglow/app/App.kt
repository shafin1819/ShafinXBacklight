package com.flashglow.app

import android.app.Application
import com.flashglow.app.core.RingEngine
import com.flashglow.app.core.Prefs

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        RingEngine.init()
    }
}
