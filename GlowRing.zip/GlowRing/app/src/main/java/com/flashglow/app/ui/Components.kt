package com.flashglow.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flashglow.app.core.Colors

object Pal {
    val bg = Color(0xFF0B0B0E)
    val card = Color(0xFF16171C)
    val line = Color(0xFF26272E)
    val text = Color(0xFFF2F2F5)
    val dim = Color(0xFF8B8D98)
    val accent = Color(0xFFFFB547)
    val led = Color(0xFFFFE6B0)
    val danger = Color(0xFFFF6B5E)
}

private val scheme: ColorScheme = darkColorScheme(
    primary = Pal.accent,
    onPrimary = Color(0xFF1A1100),
    background = Pal.bg,
    surface = Pal.card,
    onSurface = Pal.text,
)

@Composable
fun FlashTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Pal.card)
            .border(1.dp, Pal.line, RoundedCornerShape(20.dp))
            .padding(16.dp),
    ) { content() }
}

@Composable
fun SectionLabel(text: String) {
    Text(
        text.uppercase(),
        color = Pal.dim,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 1.4.sp,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp, bottom = 2.dp),
    )
}

@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Text(
        label,
        color = if (selected) Color(0xFF1A1100) else Pal.text,
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(shape)
            .background(if (selected) Pal.accent else Color(0xFF1F2026))
            .border(1.dp, if (selected) Pal.accent else Pal.line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
    )
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    onChange: (Float) -> Unit,
    onDone: () -> Unit,
    note: String? = null,
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Pal.text, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text("${(value * 100).toInt()}%", color = Pal.dim, fontSize = 13.sp)
        }
        Slider(
            value = value,
            onValueChange = onChange,
            onValueChangeFinished = onDone,
            colors = SliderDefaults.colors(
                thumbColor = Pal.accent,
                activeTrackColor = Pal.accent,
                inactiveTrackColor = Color(0xFF2A2B33),
            ),
        )
        if (note != null) Text(note, color = Pal.dim, fontSize = 11.sp)
    }
}

@Composable
fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Pal.text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(2.dp))
            Text(sub, color = Pal.dim, fontSize = 12.sp)
        }
        Spacer(Modifier.width(12.dp))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFF1A1100),
                checkedTrackColor = Pal.accent,
                uncheckedThumbColor = Pal.dim,
                uncheckedTrackColor = Color(0xFF22232A),
                uncheckedBorderColor = Pal.line,
            ),
        )
    }
}

@Composable
fun SmallButton(label: String, onClick: () -> Unit) {
    Text(
        label,
        color = Pal.accent,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .border(1.dp, Pal.accent.copy(alpha = 0.6f), RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
    )
}

private fun argb(c: Int) = Color(0xFF000000.toInt() or c)

/** Hue slider plus a row of ready-made swatches. [color] is 0xRRGGBB. */
@Composable
fun ColorPicker(color: Int, onChange: (Int) -> Unit) {
    val hueColors = (0..360 step 30).map { argb(Colors.hsv(it.toFloat() % 360f)) }
    val grey = Colors.isGrey(color)
    Column(Modifier.fillMaxWidth()) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(Colors.swatches) { sw ->
                val sel = (color and 0xFFFFFF) == sw
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(argb(sw))
                        .border(
                            if (sel) 3.dp else 1.dp,
                            if (sel) Pal.text else Pal.line,
                            CircleShape,
                        )
                        .clickable { onChange(sw) },
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.fillMaxWidth(),
            contentAlignment = Alignment.Center,
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .padding(horizontal = 10.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(hueColors)),
            )
            Slider(
                value = if (grey) 0f else Colors.hue(color) / 360f,
                onValueChange = { onChange(Colors.hsv(it * 359f)) },
                colors = SliderDefaults.colors(
                    thumbColor = argb(color),
                    activeTrackColor = Color.Transparent,
                    inactiveTrackColor = Color.Transparent,
                ),
            )
        }
    }
}
