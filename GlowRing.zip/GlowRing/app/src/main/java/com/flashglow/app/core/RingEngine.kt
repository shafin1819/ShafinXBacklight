package com.flashglow.app.core

import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.random.Random

/**
 * Runs light effects on the back ring.
 * Priority of sources: alert (notification / call / charger) > manual > game mode.
 * Only one effect coroutine drives the ring at a time, so output never interleaves.
 */
object RingEngine {
    private const val TAG = "RingEngine"
    private const val HOLD_MS = 30 * 60_000
    private const val RECLAIM_MS = 25 * 60_000L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Any()
    private val signal = Channel<Unit>(Channel.CONFLATED)

    private var manual: Request? = null
    private var game: Request? = null
    private var alertReq: Request? = null
    private var autoOffJob: Job? = null
    private var alertJob: Job? = null

    private var current: Request? = null
    private var effectJob: Job? = null
    @Volatile
    private var live: Request? = null
    private var started = false

    private val _color = MutableStateFlow(0) // colour being shown, for the on-screen phone
    val color: StateFlow<Int> = _color.asStateFlow()

    private val _manualOn = MutableStateFlow(false)
    val manualOn: StateFlow<Boolean> = _manualOn.asStateFlow()

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    @Synchronized
    fun init() {
        if (started) return
        started = true
        ShizukuState.init()
        scope.launch { for (ignored in signal) reconcile() }
    }

    // ---- public control -------------------------------------------------------------------

    fun startManual(effect: Effect, color: Int, brightness: Float, speed: Float, autoOffMin: Int) {
        _error.value = null
        synchronized(lock) {
            manual = req(effect, color, brightness, speed, "manual")
            autoOffJob?.cancel()
            autoOffJob = if (autoOffMin > 0) {
                scope.launch {
                    delay(autoOffMin * 60_000L)
                    stopManual()
                }
            } else {
                null
            }
        }
        _manualOn.value = true
        signal.trySend(Unit)
    }

    fun updateManual(effect: Effect, color: Int, brightness: Float, speed: Float) {
        val changed = synchronized(lock) {
            if (manual == null) {
                false
            } else {
                manual = req(effect, color, brightness, speed, "manual")
                true
            }
        }
        if (changed) signal.trySend(Unit)
    }

    fun stopManual() {
        synchronized(lock) {
            manual = null
            autoOffJob?.cancel()
            autoOffJob = null
        }
        _manualOn.value = false
        signal.trySend(Unit)
    }

    fun setGame(r: Request?) {
        val changed = synchronized(lock) {
            if (game == r) false else { game = r; true }
        }
        if (changed) signal.trySend(Unit)
    }

    /** Temporary effect that overrides everything else. durationMs <= 0 means until [clearAlert]. */
    fun alert(key: String, effect: Effect, color: Int, brightness: Float, speed: Float, durationMs: Long) {
        synchronized(lock) {
            alertReq = req(effect, color, brightness, speed, key)
            alertJob?.cancel()
            alertJob = if (durationMs > 0) {
                scope.launch {
                    delay(durationMs)
                    clearAlert(key)
                }
            } else {
                null
            }
        }
        signal.trySend(Unit)
    }

    fun clearAlert(key: String) {
        val changed = synchronized(lock) {
            if (alertReq?.key == key) {
                alertReq = null
                alertJob?.cancel()
                alertJob = null
                true
            } else {
                false
            }
        }
        if (changed) signal.trySend(Unit)
    }

    /** One short flash to confirm the connection works. */
    fun test() {
        alert("test", Effect.PULSE, 0x0A84FF, 1f, 0.35f, 2600)
    }

    private fun req(e: Effect, c: Int, b: Float, s: Float, key: String) =
        Request(e, c and 0xFFFFFF, b.coerceIn(0.1f, 1f), s.coerceIn(0f, 1f), key)

    // ---- driver ---------------------------------------------------------------------------

    private suspend fun reconcile() {
        val target = synchronized(lock) { alertReq ?: manual ?: game }
        val cur = current
        // Same effect, only colour / brightness / speed changed: update in place, no restart.
        if (target != null && cur != null && target.effect == cur.effect && target.key == cur.key) {
            live = target
            current = target
            return
        }
        if (target == cur) return
        effectJob?.cancelAndJoin()
        effectJob = null
        current = target
        live = target
        if (target == null) {
            _color.value = 0
            RingDriver.off()
            return
        }
        effectJob = scope.launch {
            try {
                while (true) {
                    if (!RingDriver.clear(HOLD_MS)) {
                        _error.value = RingDriver.lastError
                        if (target.key == "manual") stopManual()
                        return@launch
                    }
                    delay(RingDriver.SETTLE_MS)
                    withTimeoutOrNull(RECLAIM_MS) { runEffect() }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.w(TAG, "effect failed", e)
            }
        }
    }

    private fun send(color: Int, level: Float) {
        val l = level.coerceIn(0f, 1f)
        val b = live?.brightness ?: 1f
        val c = Colors.scale(color, l * b)
        _color.value = c
        if (!RingDriver.frame(c)) _error.value = RingDriver.lastError
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private suspend fun runEffect() {
        val effect = live?.effect ?: return
        fun p() = live!!
        val t0 = SystemClock.elapsedRealtime()
        when (effect) {
            Effect.STEADY -> {
                while (true) {
                    send(p().color, 1f)
                    delay(250)
                }
            }

            Effect.BREATHE -> while (true) {
                val period = lerp(5200f, 1600f, p().speed).toLong()
                val ph = ((SystemClock.elapsedRealtime() - t0) % period).toFloat() / period
                val wave = (1f - cos(2f * PI.toFloat() * ph)) / 2f
                send(p().color, 0.05f + 0.95f * wave)
                delay(90)
            }

            Effect.PULSE -> while (true) {
                val t = lerp(900f, 160f, p().speed).toLong()
                send(p().color, 1f); delay(t)
                send(p().color, 0f); delay(t)
            }

            Effect.HEARTBEAT -> while (true) {
                val cycle = lerp(1700f, 720f, p().speed).toLong()
                send(p().color, 1f); delay(90)
                send(p().color, 0f); delay(110)
                send(p().color, 0.7f); delay(80)
                send(p().color, 0f); delay(max(cycle - 280, 100L))
            }

            Effect.RAINBOW -> while (true) {
                val period = lerp(9000f, 2500f, p().speed)
                val hue = ((SystemClock.elapsedRealtime() - t0) % period.toLong()) / period * 360f
                send(Colors.hsv(hue), 1f)
                delay(80)
            }

            Effect.POLICE -> while (true) {
                val t = lerp(380f, 130f, p().speed).toLong()
                repeat(2) { send(0xFF0000, 1f); delay(t); send(0, 0f); delay(t / 2) }
                repeat(2) { send(0x0000FF, 1f); delay(t); send(0, 0f); delay(t / 2) }
            }

            Effect.STROBE -> while (true) {
                val period = (1000f / lerp(4f, 12f, p().speed)).toLong()
                val on = (period * 0.35f).toLong().coerceAtLeast(30)
                send(p().color, 1f); delay(on)
                send(p().color, 0f); delay(period - on)
            }

            Effect.DISCO -> while (true) {
                val k = lerp(1f, 0.4f, p().speed)
                send(Colors.hsv(Random.nextFloat() * 360f), 1f)
                delay((Random.nextLong(120, 320) * k).toLong())
            }

            Effect.MUSIC -> {
                val meter = MicMeter()
                if (!meter.start()) {
                    _error.value = "Microphone is not available"
                    awaitCancellation()
                }
                try {
                    var peak = 0.04f
                    var last = 0L
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val e = meter.read()
                        peak = max(e, peak * 0.996f).coerceAtLeast(0.04f)
                        val n = ((e - 0.015f) / (peak - 0.015f)).coerceIn(0f, 1f)
                        val now = SystemClock.elapsedRealtime()
                        if (now - last >= 45) {
                            last = now
                            send(p().color, n * n)
                        }
                    }
                } finally {
                    meter.stop()
                }
            }
        }
    }
}
