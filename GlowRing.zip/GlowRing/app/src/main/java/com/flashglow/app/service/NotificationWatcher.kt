package com.flashglow.app.service

import android.app.Notification
import android.content.Context
import android.os.PowerManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.flashglow.app.core.Effect
import com.flashglow.app.core.RingEngine
import com.flashglow.app.core.Prefs

/** Flashes the LEDs for new notifications and incoming calls. */
class NotificationWatcher : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val s = Prefs.state.value
        val n = sbn.notification ?: return
        if (sbn.packageName == packageName) return

        if (n.category == Notification.CATEGORY_CALL && n.fullScreenIntent != null) {
            if (s.callGlow) {
                RingEngine.alert(CALL_KEY, safe(s.callEffect), s.callColor, s.brightness, 0.5f, 30_000)
            }
            return
        }

        if (!s.notifGlow) return
        if (sbn.isOngoing || (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if (n.category == Notification.CATEGORY_CALL) return
        if (s.notifOnlyScreenOff) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            if (pm.isInteractive) return
        }
        RingEngine.alert("notif", safe(s.notifEffect), s.notifColor, s.brightness, 0.6f, 3500)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.notification?.category == Notification.CATEGORY_CALL) {
            RingEngine.clearAlert(CALL_KEY)
        }
    }

    // Alerts must not use the microphone effect or a flashing effect the user never agreed to.
    private fun safe(e: Effect): Effect {
        val ack = Prefs.state.value.flashyAck
        return when {
            e == Effect.MUSIC -> Effect.PULSE
            e.isFlashy && !ack -> Effect.PULSE
            else -> e
        }
    }

    companion object {
        private const val CALL_KEY = "call"
    }
}
