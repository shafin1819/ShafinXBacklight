package com.flashglow.app.core

import android.os.IBinder
import android.os.Parcel
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper

/**
 * Low-level access to the HyperOS back light ring (the LEDs around the camera lenses).
 *
 * HyperOS exposes the ring through the `miui.lights.ILightsManager` system service. Third-party
 * apps are not allowed to call it, so the calls are sent through Shizuku (which runs with shell
 * privileges). The transaction layout below follows the open-source Aura project
 * (https://github.com/tgvdufuture/Aura, MIT License), which found it by experiment on HyperOS 3.
 *
 *  - setCustomLight (txn 4): takes the strip over for a duration, then auto-clears it.
 *  - setColorCommon (txn 2): changes the colour with no timer, so it is used for animation frames.
 */
object RingDriver {
    private const val TAG = "RingDriver"
    private const val SERVICE = "miui.lights.ILightsManager"
    private const val TXN_COLOR_COMMON = 2
    private const val TXN_CUSTOM_LIGHT = 4
    private const val PKG = "com.android.camera"
    private const val STYLE_RHYTHM = 3
    private const val STYLE_CAMERA = 12
    private const val MODE_STEADY = 0

    /** HyperLightsService drops a colour sent right after a clear, so we wait between the two. */
    const val SETTLE_MS = 350L

    @Volatile
    private var cached: IBinder? = null

    @Volatile
    var lastError: String? = null
        private set

    fun shizukuRunning(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun shizukuGranted(): Boolean = runCatching {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    private fun binder(): IBinder? {
        cached?.let { if (it.pingBinder()) return it }
        cached = null
        val b = runCatching { SystemServiceHelper.getSystemService(SERVICE) }.getOrNull()
        if (b != null) cached = b
        return b
    }

    private fun transact(txn: Int, write: Parcel.() -> Unit): Boolean {
        if (!shizukuGranted()) {
            lastError = if (!shizukuRunning()) "Shizuku is not running" else "Shizuku permission not granted"
            return false
        }
        val service = binder() ?: run {
            lastError = "This phone has no back light service (miui.lights)"
            return false
        }
        val data = Parcel.obtain()
        val reply = Parcel.obtain()
        return try {
            data.writeInterfaceToken(SERVICE)
            data.write()
            ShizukuBinderWrapper(service).transact(txn, data, reply, 0)
            reply.readException()
            lastError = null
            true
        } catch (e: Exception) {
            Log.w(TAG, "transact $txn failed", e)
            cached = null
            lastError = e.message ?: e.javaClass.simpleName
            false
        } finally {
            data.recycle()
            reply.recycle()
        }
    }

    /** Takes the ring over for [onMs]; afterwards it is cleared by the system. */
    fun customLight(color: Int, flashMode: Int, onMs: Int, offMs: Int): Boolean =
        transact(TXN_CUSTOM_LIGHT) {
            writeInt(color)
            writeInt(flashMode)
            writeInt(onMs)
            writeInt(offMs)
            writeInt(0) // brightnessMode
            writeString(PKG) // must be the camera package
            writeInt(STYLE_CAMERA)
            writeInt(0) // userId
        }

    /** Timer-free colour change, used for each animation frame. 0 = dark. */
    fun frame(color: Int): Boolean =
        transact(TXN_COLOR_COMMON) {
            writeInt(color)
            writeString(PKG)
            writeInt(STYLE_RHYTHM)
            writeInt(0)
        }

    /** Clears the strip so the next colour is accepted. */
    fun clear(onMs: Int): Boolean = customLight(0, MODE_STEADY, onMs, 0)

    fun off() {
        frame(0)
        clear(1000)
    }
}
