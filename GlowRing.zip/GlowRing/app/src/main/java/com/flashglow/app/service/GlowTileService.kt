package com.flashglow.app.service

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.flashglow.app.MainActivity
import com.flashglow.app.core.Glow
import com.flashglow.app.core.Link
import com.flashglow.app.core.Prefs
import com.flashglow.app.core.RingEngine
import com.flashglow.app.core.ShizukuState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** One-tap on/off for the back light ring from the control center. */
class GlowTileService : TileService() {
    private var scope: CoroutineScope? = null

    override fun onStartListening() {
        super.onStartListening()
        ShizukuState.refresh()
        val s = CoroutineScope(Dispatchers.Main.immediate)
        scope = s
        s.launch {
            combine(RingEngine.manualOn, Prefs.state, ShizukuState.link) { on, st, link ->
                Triple(on, st.effect.label, link)
            }.collect { (on, label, link) -> render(on, label, link) }
        }
    }

    override fun onStopListening() {
        scope?.cancel()
        scope = null
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()
        ShizukuState.refresh()
        if (ShizukuState.link.value != Link.READY) {
            openApp()
            return
        }
        Glow.toggle(applicationContext)
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE),
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }

    private fun render(on: Boolean, label: String, link: Link) {
        val t = qsTile ?: return
        t.state = when {
            link != Link.READY -> Tile.STATE_INACTIVE
            on -> Tile.STATE_ACTIVE
            else -> Tile.STATE_INACTIVE
        }
        t.subtitle = when {
            link != Link.READY -> "Set up Shizuku"
            on -> label
            else -> "Off"
        }
        t.updateTile()
    }
}
