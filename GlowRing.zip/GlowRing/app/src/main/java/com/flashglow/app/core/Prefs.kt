package com.flashglow.app.core

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class Settings(
    val effect: Effect = Effect.BREATHE,
    val color: Int = 0x0A84FF,
    val brightness: Float = 1f,
    val speed: Float = 0.5f,
    val autoOffMin: Int = 0,
    val flashyAck: Boolean = false,
    val notifGlow: Boolean = false,
    val notifEffect: Effect = Effect.PULSE,
    val notifColor: Int = 0x34C759,
    val notifOnlyScreenOff: Boolean = true,
    val callGlow: Boolean = false,
    val callEffect: Effect = Effect.PULSE,
    val callColor: Int = 0xFF9500,
    val chargeGlow: Boolean = false,
    val chargeColor: Int = 0x34C759,
    val gameMode: Boolean = false,
    val gameEffect: Effect = Effect.RAINBOW,
    val gameColor: Int = 0xFF3B30,
)

object Prefs {
    private lateinit var sp: SharedPreferences
    private val _state = MutableStateFlow(Settings())
    val state: StateFlow<Settings> = _state.asStateFlow()

    fun init(context: Context) {
        if (::sp.isInitialized) return
        sp = context.applicationContext.getSharedPreferences("glowring", Context.MODE_PRIVATE)
        _state.value = read()
    }

    @Synchronized
    fun update(change: (Settings) -> Settings) {
        val next = change(_state.value)
        _state.value = next
        write(next)
    }

    private fun read(): Settings {
        val d = Settings()
        return Settings(
            effect = Effect.of(sp.getString("effect", null), d.effect),
            color = sp.getInt("color", d.color),
            brightness = sp.getFloat("brightness", d.brightness),
            speed = sp.getFloat("speed", d.speed),
            autoOffMin = sp.getInt("autoOffMin", d.autoOffMin),
            flashyAck = sp.getBoolean("flashyAck", d.flashyAck),
            notifGlow = sp.getBoolean("notifGlow", d.notifGlow),
            notifEffect = Effect.of(sp.getString("notifEffect", null), d.notifEffect),
            notifColor = sp.getInt("notifColor", d.notifColor),
            notifOnlyScreenOff = sp.getBoolean("notifOnlyScreenOff", d.notifOnlyScreenOff),
            callGlow = sp.getBoolean("callGlow", d.callGlow),
            callEffect = Effect.of(sp.getString("callEffect", null), d.callEffect),
            callColor = sp.getInt("callColor", d.callColor),
            chargeGlow = sp.getBoolean("chargeGlow", d.chargeGlow),
            chargeColor = sp.getInt("chargeColor", d.chargeColor),
            gameMode = sp.getBoolean("gameMode", d.gameMode),
            gameEffect = Effect.of(sp.getString("gameEffect", null), d.gameEffect),
            gameColor = sp.getInt("gameColor", d.gameColor),
        )
    }

    private fun write(s: Settings) {
        sp.edit()
            .putString("effect", s.effect.name)
            .putInt("color", s.color)
            .putFloat("brightness", s.brightness)
            .putFloat("speed", s.speed)
            .putInt("autoOffMin", s.autoOffMin)
            .putBoolean("flashyAck", s.flashyAck)
            .putBoolean("notifGlow", s.notifGlow)
            .putString("notifEffect", s.notifEffect.name)
            .putInt("notifColor", s.notifColor)
            .putBoolean("notifOnlyScreenOff", s.notifOnlyScreenOff)
            .putBoolean("callGlow", s.callGlow)
            .putString("callEffect", s.callEffect.name)
            .putInt("callColor", s.callColor)
            .putBoolean("chargeGlow", s.chargeGlow)
            .putInt("chargeColor", s.chargeColor)
            .putBoolean("gameMode", s.gameMode)
            .putString("gameEffect", s.gameEffect.name)
            .putInt("gameColor", s.gameColor)
            .apply()
    }
}
