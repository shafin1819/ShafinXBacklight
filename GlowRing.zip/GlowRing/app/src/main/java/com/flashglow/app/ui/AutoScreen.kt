package com.flashglow.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.flashglow.app.core.Effect
import com.flashglow.app.core.Perms
import com.flashglow.app.core.Prefs
import com.flashglow.app.service.FlashService

@Composable
fun AutoScreen() {
    val ctx: Context = LocalContext.current
    val s by Prefs.state.collectAsStateWithLifecycle()

    // Re-check permissions whenever the user comes back from system settings.
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    val listener = remember(tick) { Perms.hasListenerAccess(ctx) }
    val usage = remember(tick) { Perms.hasUsageAccess(ctx) }
    val postNotif = remember(tick) { Perms.hasPostNotifications(ctx) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val alertEffects = Effect.entries.filter { it != Effect.MUSIC && it != Effect.STEADY && (!it.isFlashy || s.flashyAck) }

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (!postNotif) {
            Card {
                Text("Allow notifications", color = Pal.text, fontSize = 15.sp)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Needed so Android can show the small \"GlowRing is active\" notice while the light runs.",
                    color = Pal.dim, fontSize = 12.sp,
                )
                Spacer(Modifier.height(10.dp))
                SmallButton("Allow") { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
            }
        }

        SectionLabel("Alerts")
        Card {
            ToggleRow(
                "Notification glow",
                "Light the ring when a new notification arrives",
                s.notifGlow && listener,
            ) { v ->
                if (v && !listener) openListenerSettings(ctx)
                else Prefs.update { it.copy(notifGlow = v) }
            }
            if (!listener) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Needs notification access", color = Pal.dim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    SmallButton("Grant") { openListenerSettings(ctx) }
                }
            } else if (s.notifGlow) {
                Spacer(Modifier.height(10.dp))
                ToggleRow("Only when screen is off", "Skip the glow while you are using the phone", s.notifOnlyScreenOff) { v ->
                    Prefs.update { it.copy(notifOnlyScreenOff = v) }
                }
                Spacer(Modifier.height(10.dp))
                EffectPicker(s.notifEffect, alertEffects) { e -> Prefs.update { it.copy(notifEffect = e) } }
                Spacer(Modifier.height(10.dp))
                ColorPicker(s.notifColor) { c -> Prefs.update { it.copy(notifColor = c) } }
            }
        }

        Card {
            ToggleRow(
                "Incoming call",
                "Keep glowing while the phone rings",
                s.callGlow && listener,
            ) { v ->
                if (v && !listener) openListenerSettings(ctx)
                else Prefs.update { it.copy(callGlow = v) }
            }
            if (s.callGlow && listener) {
                Spacer(Modifier.height(10.dp))
                EffectPicker(s.callEffect, alertEffects) { e -> Prefs.update { it.copy(callEffect = e) } }
                Spacer(Modifier.height(10.dp))
                ColorPicker(s.callColor) { c -> Prefs.update { it.copy(callColor = c) } }
            }
        }

        Card {
            ToggleRow("Charger plugged in", "A soft breathing glow when you connect power", s.chargeGlow) { v ->
                Prefs.update { it.copy(chargeGlow = v) }
                FlashService.refresh(ctx)
            }
            if (s.chargeGlow) {
                Spacer(Modifier.height(10.dp))
                ColorPicker(s.chargeColor) { c -> Prefs.update { it.copy(chargeColor = c) } }
            }
        }

        SectionLabel("Gaming")
        Card {
            ToggleRow(
                "Game mode",
                "Light up automatically while a game is open",
                s.gameMode && usage,
            ) { v ->
                if (v && !usage) openUsageSettings(ctx)
                else {
                    Prefs.update { it.copy(gameMode = v) }
                    FlashService.refresh(ctx)
                }
            }
            if (!usage) {
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Needs usage access to see the open app", color = Pal.dim, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    SmallButton("Grant") { openUsageSettings(ctx) }
                }
            } else if (s.gameMode) {
                Spacer(Modifier.height(10.dp))
                EffectPicker(s.gameEffect, Effect.entries.filter { it != Effect.MUSIC && (!it.isFlashy || s.flashyAck) }) { e ->
                    Prefs.update { it.copy(gameEffect = e) }
                }
                Spacer(Modifier.height(10.dp))
                ColorPicker(s.gameColor) { c -> Prefs.update { it.copy(gameColor = c) } }
                Spacer(Modifier.height(6.dp))
                Text("Apps that Android marks as games are detected automatically.", color = Pal.dim, fontSize = 11.sp)
            }
        }

        Text(
            "Alerts take priority over the manual light, and the manual light over game mode.",
            color = Pal.dim, fontSize = 11.sp,
        )
    }
}

@Composable
private fun EffectPicker(current: Effect, options: List<Effect>, onPick: (Effect) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(options) { e -> Chip(e.label, current == e) { onPick(e) } }
    }
}

private fun openListenerSettings(c: Context) {
    c.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private fun openUsageSettings(c: Context) {
    c.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}
