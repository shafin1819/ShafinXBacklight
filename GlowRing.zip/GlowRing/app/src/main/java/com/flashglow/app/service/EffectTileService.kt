package com.flashglow.app.service

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import com.flashglow.app.core.Glow
import com.flashglow.app.core.Prefs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** Each tap switches to the next light effect. */
class EffectTileService : TileService() {
    private var scope: CoroutineScope? = null

    override fun onStartListening() {
        super.onStartListening()
        val s = CoroutineScope(Dispatchers.Main.immediate)
        scope = s
        s.launch {
            Prefs.state.collect { st ->
                val t = qsTile ?: return@collect
                t.state = Tile.STATE_ACTIVE
                t.subtitle = st.effect.label
                t.updateTile()
            }
        }
    }

    override fun onStopListening() {
        scope?.cancel()
        scope = null
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()
        val c = applicationContext
        val list = Glow.cycleList(c, Prefs.state.value)
        if (list.isEmpty()) return
        val idx = list.indexOf(Prefs.state.value.effect)
        val next = list[(idx + 1) % list.size]
        Prefs.update { it.copy(effect = next) }
        Glow.apply(c)
    }
}
