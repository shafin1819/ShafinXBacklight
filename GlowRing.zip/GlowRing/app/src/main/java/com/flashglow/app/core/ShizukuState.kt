package com.flashglow.app.core

import android.content.Intent
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

enum class Link { NOT_RUNNING, NEED_PERMISSION, READY }

/** Tracks whether Shizuku is running and has allowed this app. */
object ShizukuState {
    private val _link = MutableStateFlow(Link.NOT_RUNNING)
    val link: StateFlow<Link> = _link.asStateFlow()
    private var started = false

    @Synchronized
    fun init() {
        if (started) return
        started = true
        runCatching {
            Shizuku.addBinderReceivedListenerSticky { refresh() }
            Shizuku.addBinderDeadListener { refresh() }
            Shizuku.addRequestPermissionResultListener { _, _ -> refresh() }
        }
        refresh()
    }

    fun refresh() {
        _link.value = when {
            !RingDriver.shizukuRunning() -> Link.NOT_RUNNING
            !RingDriver.shizukuGranted() -> Link.NEED_PERMISSION
            else -> Link.READY
        }
    }

    fun requestPermission() {
        runCatching {
            if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(1000)
            }
        }
    }

    /** Opens the Shizuku app so the user can start it. Returns false if it is not installed. */
    fun openShizukuApp(c: Context): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api") ?: return false
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}
