package com.flashglow.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.flashglow.app.core.RingEngine
import com.flashglow.app.core.Prefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        Prefs.init(context)
        RingEngine.init()
        val s = Prefs.state.value
        if (s.chargeGlow || s.gameMode) FlashService.start(context)
    }
}
