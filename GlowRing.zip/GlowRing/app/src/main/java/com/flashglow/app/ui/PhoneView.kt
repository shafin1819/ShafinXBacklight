package com.flashglow.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import kotlinx.coroutines.launch

/**
 * Drag-to-rotate phone. The rotation is done by the GPU (graphicsLayer) and the two
 * camera LEDs light up in real time with [glow] (0..1) and [tint].
 */
@Composable
fun PhoneView(ring: Int, modifier: Modifier = Modifier) {
    val rot = remember { Animatable(-18f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current.density

    LaunchedEffect(Unit) { rot.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 40f)) }

    Box(
        modifier
            .fillMaxWidth()
            .aspectRatio(0.62f)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = {
                        scope.launch {
                            // Settle on whichever face is closest.
                            val turns = Math.round(rot.value / 180f)
                            rot.animateTo(turns * 180f, spring(dampingRatio = 0.7f, stiffness = 120f))
                        }
                    },
                ) { change, drag ->
                    change.consume()
                    scope.launch { rot.snapTo(rot.value + drag.x * 0.55f) }
                }
            }
            .graphicsLayer {
                rotationY = rot.value
                rotationX = -6f
                cameraDistance = 16f * density
            },
    ) {
        val a = ((rot.value % 360f) + 360f) % 360f
        val showBack = a < 90f || a > 270f
        Canvas(Modifier.matchParentSize()) {
            val on = ring != 0
            val tint = Color(0xFF000000.toInt() or ring)
            val glow = if (on) 1f else 0f
            if (showBack) drawBack(glow, tint) else drawFront(glow, tint)
        }
    }
}

private fun DrawScope.body(radius: Float) {
    val w = size.width * 0.78f
    val h = size.height * 0.94f
    val tl = Offset((size.width - w) / 2f, (size.height - h) / 2f)
    // ground shadow
    drawRoundRect(
        Color(0x66000000), tl + Offset(0f, h * 0.02f), Size(w, h), CornerRadius(radius),
    )
    // metal frame
    drawRoundRect(
        Brush.linearGradient(
            listOf(Color(0xFF8A8D95), Color(0xFF2A2C32), Color(0xFF9EA1A9)),
            start = tl, end = tl + Offset(w, h),
        ),
        tl, Size(w, h), CornerRadius(radius),
    )
}

private fun DrawScope.drawBack(glow: Float, tint: Color) {
    val w = size.width * 0.78f
    val h = size.height * 0.94f
    val x0 = (size.width - w) / 2f
    val y0 = (size.height - h) / 2f
    val r = w * 0.14f
    body(r)

    val inset = w * 0.018f
    drawRoundRect(
        Brush.linearGradient(
            listOf(Color(0xFF23262D), Color(0xFF14161B), Color(0xFF2B2F38)),
            start = Offset(x0, y0), end = Offset(x0 + w, y0 + h),
        ),
        Offset(x0 + inset, y0 + inset), Size(w - 2 * inset, h - 2 * inset), CornerRadius(r - inset),
    )
    // glass sheen
    drawRoundRect(
        Brush.linearGradient(
            listOf(Color(0x00FFFFFF), Color(0x22FFFFFF), Color(0x00FFFFFF)),
            start = Offset(x0, y0 + h * 0.15f), end = Offset(x0 + w, y0 + h * 0.55f),
        ),
        Offset(x0 + inset, y0 + inset), Size(w - 2 * inset, h - 2 * inset), CornerRadius(r - inset),
    )

    // camera island: two lenses stacked, each with a light ring around it (like the real phone)
    val iw = w * 0.34f
    val ih = w * 0.66f
    val ix = x0 + w * 0.09f
    val iy = y0 + w * 0.09f
    drawRoundRect(Color(0xFF2B2D33), Offset(ix, iy), Size(iw, ih), CornerRadius(iw / 2f))
    drawRoundRect(
        Color(0xFF3A3D45), Offset(ix, iy), Size(iw, ih), CornerRadius(iw / 2f), style = Stroke(w * 0.008f),
    )

    val lensR = iw * 0.27f
    val centers = listOf(Offset(ix + iw / 2f, iy + iw / 2f), Offset(ix + iw / 2f, iy + ih - iw / 2f))
    for (c in centers) {
        if (glow > 0.01f) {
            drawCircle(
                Brush.radialGradient(
                    listOf(tint.copy(alpha = 0.55f), tint.copy(alpha = 0.18f), Color.Transparent),
                    center = c, radius = w * 0.42f,
                ),
                w * 0.42f, c,
            )
        }
        drawCircle(Color(0xFF0B0C0F), iw * 0.46f, c)
        // the ring
        drawCircle(
            if (glow > 0.01f) tint else Color(0xFF55585F),
            lensR * 1.32f, c, style = Stroke(w * 0.014f),
        )
        drawCircle(Color(0xFF050608), lensR, c)
        drawCircle(
            Brush.radialGradient(
                listOf(Color(0xFF3F4F8F), Color(0xFF111426), Color(0xFF050608)),
                center = Offset(c.x - lensR * 0.25f, c.y - lensR * 0.25f), radius = lensR,
            ),
            lensR * 0.72f, c,
        )
        drawCircle(Color(0x66FFFFFF), lensR * 0.12f, Offset(c.x - lensR * 0.3f, c.y - lensR * 0.32f))
    }
    // flash pill next to the island
    drawRoundRect(
        Color(0xFF4B4D54), Offset(ix + iw + w * 0.04f, iy + ih * 0.36f),
        Size(w * 0.035f, w * 0.12f), CornerRadius(w),
    )

    // brand mark
    drawCircle(Color(0x22FFFFFF), w * 0.04f, Offset(x0 + w / 2f, y0 + h * 0.78f), style = Stroke(w * 0.008f))
}

private fun DrawScope.drawFront(glow: Float, tint: Color) {
    val w = size.width * 0.78f
    val h = size.height * 0.94f
    val x0 = (size.width - w) / 2f
    val y0 = (size.height - h) / 2f
    val r = w * 0.14f
    body(r)
    val inset = w * 0.03f
    val sx = x0 + inset
    val sy = y0 + inset
    val sw = w - 2 * inset
    val sh = h - 2 * inset
    drawRoundRect(Color(0xFF050507), Offset(sx, sy), Size(sw, sh), CornerRadius(r - inset))

    // Light spilling around the edges to hint the effect
    if (glow > 0.01f) {
        drawRoundRect(
            tint.copy(alpha = 0.55f * glow), Offset(sx, sy), Size(sw, sh), CornerRadius(r - inset),
            style = Stroke(w * 0.012f),
        )
    }
    // punch-hole
    drawCircle(Color(0xFF15161A), sw * 0.025f, Offset(sx + sw / 2f, sy + sw * 0.06f))
    // simple wallpaper bars
    for (i in 0 until 3) {
        val yy = sy + sh * (0.3f + i * 0.13f)
        drawRoundRect(
            Color(0x14FFFFFF), Offset(sx + sw * 0.12f, yy), Size(sw * (0.76f - i * 0.18f), sh * 0.03f),
            CornerRadius(sh),
        )
    }
}
