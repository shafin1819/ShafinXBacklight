package com.flashglow.app.core

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.max
import kotlin.math.sqrt

/** Tiny microphone level meter used by the Music effect. */
class MicMeter {
    private var rec: AudioRecord? = null
    private val buf = ShortArray(512)

    @SuppressLint("MissingPermission")
    fun start(): Boolean = try {
        val rate = 22050
        val min = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
        )
        if (min <= 0) {
            false
        } else {
            val r = AudioRecord(
                MediaRecorder.AudioSource.MIC, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                max(min, 4096),
            )
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                r.release()
                false
            } else {
                r.startRecording()
                rec = r
                true
            }
        }
    } catch (e: Exception) {
        false
    }

    /** Blocks for about 23 ms and returns the RMS level (0..1). */
    fun read(): Float {
        val r = rec ?: return 0f
        val n = r.read(buf, 0, buf.size)
        if (n <= 0) return 0f
        var sum = 0.0
        for (i in 0 until n) {
            val v = buf[i] / 32768.0
            sum += v * v
        }
        return sqrt(sum / n).toFloat()
    }

    fun stop() {
        try { rec?.stop() } catch (_: Exception) { }
        rec?.release()
        rec = null
    }
}
